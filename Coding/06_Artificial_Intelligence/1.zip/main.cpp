#include "Test.h"

/*
Test F1(Test &&a){
		cout << "fuck1" << endl;
    Test b = a;
		cout << "fuck2" << endl;
    return b;
}
void test1(){
    Test A = F1(1);
		cout << "fuck3" << endl;
}


Test&& F2(Test &a){
		cout << "fuck2" << endl;
    Test b = a;
		cout << "fuck3" << endl;
    return std::move(b);
}
void test2(){
    Test tmp;
		cout << "fuck1" << endl;
    Test A = F2(tmp);
		cout << "fuck4" << endl;
}
*/
const Test& F3(const Test& a){
		cout << "fuck3" << endl;
    Test b = a;
		cout << "fuck4" << endl;
    return std::move(b);
}

void test3() {
		cout << "fuck1" << endl;
    Test a;
		cout << "fuck2" << endl;
    const Test& A = F3(std::move(a));
		Test B = std::move(A);
		cout << "fuck5" << endl;
}
/*
Test F4(const Test& a){
		cout << "fuck2" << endl;
    Test b = std::move(a); 
		cout << "fuck3" << endl;
    return b;
}
void test4(){
		cout << "fuck1" << endl;
    Test A = F4(1);
		cout << "fuck4" << endl;
}

const Test& F5(Test a){
		cout << "fuck3" << endl;
    Test& b = a;
		cout << "fuck4" << endl;
    return b;
}
void test5(){
		cout << "fuck1" << endl;
    Test a;
		cout << "fuck2" << endl;
    Test A = F5(a);
		cout << "fuck5" << endl;
}
*/
int main(){
		test3();
		Test::outputResult();
    return 0;
}